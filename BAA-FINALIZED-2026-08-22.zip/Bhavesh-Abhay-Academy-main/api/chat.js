// api/chat.js
// BAA OS — AI Tutor backend
// Runs as a Vercel Edge Function. Keeps the Gemini API key server-side,
// validates and trims incoming conversations, applies basic rate limiting,
// retries transient failures, and streams the model's reply back to the
// browser as Server-Sent Events (SSE).

export const config = { runtime: 'nodejs' };

import { requireAuth } from './_lib/auth.js';
import { consumeAiRateLimit } from './_lib/ai-rate-limit.js';

// ---------- Configuration ----------
// gemini-3.5-flash-lite is Google's current GA, production-ready Flash-Lite
// model (as of mid-2026) and remains on the free tier. We moved to it from
// gemini-3.6-flash after repeatedly hitting that model's free-tier daily
// quota (RPD) in production. gemini-2.5-flash has begun returning 404s
// ahead of its official Oct 16, 2026 shutdown, so we no longer use it.
const MODEL = 'gemini-3.5-flash-lite';
const GEMINI_API_URL = `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:streamGenerateContent?alt=sse`;
const MAX_OUTPUT_TOKENS = 2048;
const MAX_MESSAGE_CHARS = 4000;             // per-message cap
const MAX_HISTORY_MESSAGES = 20;            // how many turns of memory we forward to the model
const REQUEST_TIMEOUT_MS = 30_000;
const MAX_RETRIES = 2;

// ---------- Image understanding (additive — see toGeminiContents/validateMessages) ----------
// gemini-3.5-flash-lite accepts inline image parts natively; no separate vision
// model or endpoint is needed. Cap is on the base64 STRING length (cheap check,
// no decode needed) — 7M base64 chars is roughly 5.25MB decoded, comfortably
// under Vercel Edge's request body ceiling once JSON overhead is included. The
// frontend (js/image.js) compresses client-side well below this before upload;
// this is a server-side backstop, not the primary size control.
const ALLOWED_IMAGE_MIME_TYPES = new Set(['image/png', 'image/jpeg', 'image/webp']);
const MAX_IMAGE_BASE64_CHARS = 7_000_000;


function getAllowedOrigin(req) {
  // Set ALLOWED_ORIGIN in Vercel env vars to your GitHub Pages URL, e.g.
  // "https://yourusername.github.io". Falls back to "*" (open) if unset —
  // tighten this before going fully live.
  return process.env.ALLOWED_ORIGIN || '*';
}

function corsHeaders(req) {
  return {
    'Access-Control-Allow-Origin': getAllowedOrigin(req),
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Vary': 'Origin',
  };
}

function jsonError(req, status, message) {
  return new Response(JSON.stringify({ error: message }), {
    status,
    headers: { 'Content-Type': 'application/json', ...corsHeaders(req) },
  });
}

function getClientIp(req) {
  const fwd = req.headers.get('x-forwarded-for');
  if (fwd) return fwd.split(',')[0].trim();
  return req.headers.get('x-real-ip') || 'unknown';
}


function sanitizeName(name) {
  if (typeof name !== 'string') return 'Explorer';
  const cleaned = name.replace(/[^a-zA-Z0-9 '-]/g, '').trim().slice(0, 40);
  return cleaned || 'Explorer';
}

// Hard abuse ceiling — this is NOT the normal memory-management limit.
// Legitimate long conversations are trimmed below and should never hit this;
// it only exists to reject clearly malformed/malicious payloads (e.g. a
// broken client looping and sending thousands of entries) before we waste
// time validating/serializing them.
const ABUSE_CEILING_MESSAGES = 500;

function validateMessages(messages) {
  if (!Array.isArray(messages) || messages.length === 0) {
    return { error: 'messages must be a non-empty array' };
  }
  if (messages.length > ABUSE_CEILING_MESSAGES) {
    return { error: 'conversation payload malformed — please start a new conversation' };
  }
  // Trim to the most recent turns FIRST, before per-message validation.
  // Previously this trim happened after a hard length check, so any normal
  // conversation that grew past that check was rejected outright instead of
  // ever reaching the trim — that was the actual "conversation too long" bug.
  // Now we only validate/forward the window we're actually going to send.
  messages = messages.slice(-MAX_HISTORY_MESSAGES);
  for (const m of messages) {
    if (!m || (m.role !== 'user' && m.role !== 'assistant')) {
      return { error: 'each message needs role "user" or "assistant"' };
    }
    if (typeof m.content !== 'string' || !m.content.trim()) {
      return { error: 'each message needs non-empty string content' };
    }
    if (m.content.length > MAX_MESSAGE_CHARS) {
      return { error: `message exceeds ${MAX_MESSAGE_CHARS} characters` };
    }
    if (m.image !== undefined && m.image !== null) {
      if (typeof m.image !== 'object') {
        return { error: 'image must be an object with mimeType and data' };
      }
      if (!ALLOWED_IMAGE_MIME_TYPES.has(m.image.mimeType)) {
        return { error: 'unsupported image format — use PNG, JPEG, or WEBP' };
      }
      if (typeof m.image.data !== 'string' || !m.image.data.trim()) {
        return { error: 'image data is missing' };
      }
      if (m.image.data.length > MAX_IMAGE_BASE64_CHARS) {
        return { error: 'image is too large — please upload a smaller or more compressed image' };
      }
    }
  }
  // Already trimmed to MAX_HISTORY_MESSAGES above, before validation ran.
  return { messages };
}

// Gemini uses role "model" where our own history (and Anthropic-style
// convention) uses "assistant" — translate on the way out. When a message
// carries an image, its part is placed BEFORE the text part — Google's own
// guidance is that leading with the image improves grounding versus putting
// the instruction first.
function toGeminiContents(messages) {
  return messages.map((m) => {
    const parts = [];
    if (m.image && m.image.mimeType && m.image.data) {
      parts.push({ inlineData: { mimeType: m.image.mimeType, data: m.image.data } });
    }
    parts.push({ text: m.content });
    return {
      role: m.role === 'assistant' ? 'model' : 'user',
      parts,
    };
  });
}

// Debug-logging only — returns a deep copy of the payload with any inline
// image base64 data replaced by a short placeholder, so uploaded images never
// end up verbatim in Vercel's function logs. The real `payload` object sent
// to Gemini is never touched by this.
function redactImageDataForLogging(payload) {
  try {
    const clone = JSON.parse(JSON.stringify(payload));
    for (const c of clone.contents || []) {
      for (const p of c.parts || []) {
        if (p.inlineData && typeof p.inlineData.data === 'string') {
          p.inlineData.data = `<omitted, ${p.inlineData.data.length} base64 chars>`;
        }
      }
    }
    return clone;
  } catch {
    return { note: 'payload redaction failed, not logging raw payload' };
  }
}

async function callGeminiWithRetry(payload, apiKey, attempt = 0) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);

  try {
    const response = await fetch(GEMINI_API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-goog-api-key': apiKey,
      },
      body: JSON.stringify(payload),
      signal: controller.signal,
    });

    // Retry on transient server-side failures only (not on 4xx — those are our bug).
    if (!response.ok && response.status >= 500 && attempt < MAX_RETRIES) {
      clearTimeout(timeout);
      await new Promise((r) => setTimeout(r, 400 * Math.pow(2, attempt)));
      return callGeminiWithRetry(payload, apiKey, attempt + 1);
    }

    clearTimeout(timeout);
    return response;
  } catch (err) {
    clearTimeout(timeout);
    const isAbort = err.name === 'AbortError';
    if (attempt < MAX_RETRIES) {
      await new Promise((r) => setTimeout(r, 400 * Math.pow(2, attempt)));
      return callGeminiWithRetry(payload, apiKey, attempt + 1);
    }
    throw new Error(isAbort ? 'upstream timeout' : 'upstream network error');
  }
}

export default async function handler(req) {
  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 204, headers: corsHeaders(req) });
  }

  if (req.method !== 'POST') {
    return jsonError(req, 405, 'Method not allowed');
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return jsonError(req, 500, 'Server is missing GEMINI_API_KEY');
  }

  let session;
  try { session = await requireAuth(req); } catch (e) {
    return jsonError(req, e.status || 401, e.message || 'Authentication required.');
  }
  let rate;
  try { rate = await consumeAiRateLimit('chat', session.user_id || getClientIp(req), { windowSeconds: 300, maxRequests: 20 }); }
  catch { return jsonError(req, 503, 'AI rate-limit service is temporarily unavailable.'); }
  if (rate.limited) return jsonError(req, 429, 'Too many requests — please wait a moment and try again.');

  let body;
  try {
    body = await req.json();
  } catch {
    return jsonError(req, 400, 'Invalid JSON body');
  }

  const { messages, studentName, learningContext, mode, explainLikeMode, responseLanguage } = body || {};
  const safeMode = mode === 'mentor' ? 'mentor' : 'tutor';
  const allowedExplainLike = new Set(['default','child','story','everyday','exam','visual']);
  const safeExplainLike = allowedExplainLike.has(explainLikeMode) ? explainLikeMode : 'default';
  const allowedResponseLanguages = new Set(['en','hi','mr','gu','bn','ta','te','kn']);
  const safeResponseLanguage = allowedResponseLanguages.has(responseLanguage) ? responseLanguage : 'en';
  const responseLanguageNames = {en:'English',hi:'Hindi',mr:'Marathi',gu:'Gujarati',bn:'Bengali',ta:'Tamil',te:'Telugu',kn:'Kannada'};
  const responseLanguageName = responseLanguageNames[safeResponseLanguage];
  const validated = validateMessages(messages);
  if (validated.error) {
    return jsonError(req, 400, validated.error);
  }

  const safeName = sanitizeName(studentName);
  // Section B connection: an optional, factual summary of the student's
  // real assessment evidence (built client-side by
  // BAAAssessment.getLearningContextForTutor() — see js/baa-assessment.js).
  // Bounded and type-checked here since it's untrusted client input; on
  // any doubt it is simply dropped rather than passed through.
  const MAX_LEARNING_CONTEXT_CHARS = 1200;
  const safeLearningContext = (typeof learningContext === 'string' && learningContext.trim())
    ? learningContext.trim().slice(0, MAX_LEARNING_CONTEXT_CHARS)
    : null;
  const explainLikeInstruction = safeMode === 'tutor' && safeExplainLike !== 'default'
    ? ({
      child: 'Explain simply for a younger learner; simplify language without changing facts.',
      story: 'Use one short story analogy and clearly label it as an analogy.',
      everyday: 'Use one familiar everyday-life analogy and state its limits.',
      exam: 'Use an exam-focused explanation with key idea, common trap, worked example, and check question.',
      visual: 'Use a concrete visual/spatial analogy described in words; do not claim an image was generated.'
    }[safeExplainLike] || '')
    : '';
  const languageInstruction = safeResponseLanguage !== 'en'
    ? `\n\nRESPONSE LANGUAGE — Reply in ${responseLanguageName}. Preserve mathematical notation, code, proper nouns, and essential scientific/technical terminology accurately. Do not translate code syntax. If a technical term is clearer in English, retain the original term in parentheses.`
    : '';
  const systemPrompt = safeMode === 'mentor'
    ? `You are the BAA AI Mentor Chat, talking to a school student named ${safeName}. ` +
      `Your job is academic guidance and motivation: help the student reflect on goals, choose a realistic next step, build confidence through evidence, and stay oriented toward learning. ` +
      `You are not the student's therapist, doctor, parent, teacher, or best friend. Do not diagnose, manipulate, shame, pressure, or create dependency. ` +
      `Do not invent grades, achievements, weaknesses, schedules, or personal facts. Use the supplied learning evidence only when relevant and describe it as evidence, not as a diagnosis. ` +
      `For decisions that require a teacher, parent, school, or qualified professional, say so clearly. ` +
      `Prefer one or two concrete next actions over long motivational speeches. Keep the tone warm, encouraging, age-appropriate, and professionally bounded. ` +
      `If the student is discouraged, acknowledge the difficulty and help them identify a small achievable academic step. ` +
      `If they ask for a study plan, ask for missing constraints only when necessary; otherwise propose a simple plan grounded in the available evidence. ` +
      `If you are uncertain about a fact, say so rather than guessing. ` +
      `FORMAT — Use markdown for structure when helpful. For math, use LaTeX with $...$ or $$...$$.`
    : `You are the BAA AI Tutor, talking to a school student named ${safeName}. ` +
    `Your job is not to answer questions — it is to help ${safeName} understand, so they can ` +
    `answer it themselves next time.\n\n` +
    `CORE TEACHING RULE — Do not give the final answer/solution immediately by default. Follow ` +
    `this progression, adapting it intelligently rather than forcing every single step: ` +
    `(1) try to gauge the student's level from what they've said, ` +
    `(2) ask a guiding question that points at the gap rather than stating it, ` +
    `(3) if still stuck, give one small hint, ` +
    `(4) if still stuck, give a second, more specific hint, ` +
    `(5) if still stuck, break the concept into a simpler piece, ` +
    `(6) show ONE worked example using DIFFERENT numbers than their actual question, ` +
    `(7) only then show the full worked solution to their original question, ` +
    `(8) give them a fresh, similar practice question, ` +
    `(9) when they answer, check whether they actually applied the idea or just pattern-matched. ` +
    `Skip steps for a student who is clearly close to the answer. Slow down and repeat steps for ` +
    `a student who is clearly lost. If the student directly and clearly asks for the answer, ask ` +
    `once ("Want one more hint, or should I just show you?") and then respect their choice — do not ` +
    `refuse to ever answer.\n\n` +
    `SELF-EXPLANATION — Periodically (not every message) ask the student to explain a step back in ` +
    `their own words rather than immediately moving on. This checks real understanding, not just a ` +
    `correct final answer.\n\n` +
    `UNCERTAINTY — If you are not confident about a fact, a curriculum detail, or a step, say so ` +
    `plainly ("I'm not fully sure about this part — let's double check together") instead of ` +
    `answering with false confidence. For math and numeric answers, show your working so a wrong ` +
    `step is visible and fixable, not just a final number.\n\n` +
    `TONE — Warm, encouraging, and age-appropriate for a school student. Never frame a mistake as a ` +
    `failure — mistakes are information, not something to be embarrassed about. Keep answers short ` +
    `(roughly 3-6 sentences unless a worked example needs more room), simple, and end with a small ` +
    `encouraging nudge or a follow-up question. You are a tutor, not a friend or companion — keep the ` +
    `relationship warm but professional; do not adopt a personal or romantic tone.\n\n` +
    `FORMAT — Use markdown for structure when it helps (e.g. **bold**, short lists, \`code\`, or fenced ` +
    `code blocks). For math, write expressions in LaTeX using $...$ for inline and $$...$$ for ` +
    `block equations.\n\n` +
    `IMAGES — The student can attach a photo — a worksheet, textbook page, diagram, handwritten notes, ` +
    `map, chart, graph, or table. When an image is attached, look at it carefully before answering: ` +
    `read every label, number, and line of handwriting, and refer to specific parts of the image in ` +
    `your answer (e.g. "In Question 5..." or "The diagram's third label...").` +
    (safeLearningContext
      ? `\n\nASSESSMENT EVIDENCE — ${safeLearningContext}\n` +
        `Use this only if it's actually relevant to what the student is asking right now — do not ` +
        `bring it up unprompted, do not read it back to them verbatim, and do not treat it as a ` +
        `diagnosis. It's a "possible misconception" signal from graded assessments, not a fact about ` +
        `the student.`
      : '');

  if (explainLikeInstruction) {
    systemPrompt += `\n\nEXPLAIN LIKE MODE — ${explainLikeInstruction}`;
  }
  if (languageInstruction) systemPrompt += languageInstruction;

  const payload = {
    system_instruction: { parts: [{ text: systemPrompt }] },
    contents: toGeminiContents(validated.messages),
    generationConfig: {
      maxOutputTokens: MAX_OUTPUT_TOKENS,
      thinkingConfig: {
        thinkingLevel: 'low',
      },
      // Note: temperature/top_p/top_k are deprecated for the Gemini 3.x
      // family (Google recommends the model's default of 1.0) — omitted
      // intentionally, not an oversight.
    },
    safetySettings: [
      // Keep Google's default child-safety blocking; only relax categories
      // that commonly false-positive on ordinary schoolwork topics.
      { category: 'HARM_CATEGORY_DANGEROUS_CONTENT', threshold: 'BLOCK_MEDIUM_AND_ABOVE' },
    ],
  };

  // --- Return the streaming Response immediately. We do NOT await Gemini
  // here — Vercel Edge Functions must send an initial response quickly
  // (the platform will kill the invocation with "did not return an initial
  // response" if we sit here awaiting a slow upstream call first). Instead,
  // the Gemini call — including retries — happens inside the ReadableStream's
  // start(), after the Response has already been handed back to the platform.
  const encoder = new TextEncoder();
  const stream = new ReadableStream({
    async start(controller) {
      // Send an immediate SSE comment (lines starting with ':' are ignored
      // by SSE parsers, including the frontend's) so real bytes hit the wire
      // right away. This satisfies Vercel Edge's requirement to begin
      // sending a response within 25 seconds, independent of how long the
      // upstream Gemini call ends up taking.
      controller.enqueue(encoder.encode(': connected\n\n'));

      let upstream;
      try {
        upstream = await callGeminiWithRetry(payload, apiKey);
      } catch (err) {
        controller.enqueue(
          encoder.encode(`data: ${JSON.stringify({ error: { message: err.message || 'Failed to reach the AI service' } })}\n\n`)
        );
        controller.close();
        return;
      }

      if (!upstream.ok) {
        let detail = 'AI service error';
        try {
          const errBody = await upstream.json();
          // Gemini errors can come back as an object or a single-element array.
          const errObj = Array.isArray(errBody) ? errBody[0]?.error : errBody?.error;
          detail = errObj?.message || detail;
        } catch (parseErr) {
          /* ignore parse failure, use default message */
        }
        controller.enqueue(
          encoder.encode(`data: ${JSON.stringify({ error: { message: detail } })}\n\n`)
        );
        controller.close();
        return;
      }

      // Re-stream Gemini's SSE events straight through to the browser. The
      // frontend parses each `data:` line's JSON for candidates[0].content.parts.
      const reader = upstream.body.getReader();

      try {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          controller.enqueue(value);
        }
      } catch (e) {
        controller.enqueue(
          encoder.encode(`data: ${JSON.stringify({ error: { message: 'stream interrupted' } })}\n\n`)
        );
      } finally {
        controller.close();
      }
    },
  });

  return new Response(stream, {
    status: 200,
    headers: {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache, no-transform',
      Connection: 'keep-alive',
      'X-Accel-Buffering': 'no',
      ...corsHeaders(req),
    },
  });
}
